function z=eval_c1ux(x,y)
phi=x;
theta=y;
z=(18/25).*cos(phi).^3.*sin(phi).*sin(theta).^4;
